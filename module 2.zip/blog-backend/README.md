# Blog Backend (Module 2)

Node.js + Express + MongoDB (Mongoose) + JWT authentication.

## Setup
1. Install Node.js and MongoDB (or use a free MongoDB Atlas cluster).
2. In this folder run:  `npm install`
3. Edit `.env` (set `MONGO_URI` and a strong `JWT_SECRET`).
4. Start the server:  `npm run dev`   (or `npm start`)
5. Open `frontend/index.html` in the browser.

## API
| Method | Endpoint             | Auth | Body                         |
|--------|----------------------|------|------------------------------|
| POST   | /api/auth/register   | No   | name, email, password        |
| POST   | /api/auth/login      | No   | email, password              |
| GET    | /api/blogs           | No   | -                            |
| GET    | /api/blogs/:id       | No   | -                            |
| POST   | /api/blogs           | Yes  | title, content               |
| DELETE | /api/blogs/:id       | Yes  | - (owner only)               |

Protected routes need the header: `Authorization: Bearer <token>`

## Test with curl
```
curl -X POST http://localhost:5000/api/auth/register -H "Content-Type: application/json" -d '{"name":"Jawad","email":"jawad@test.com","password":"123456"}'
curl -X POST http://localhost:5000/api/blogs -H "Content-Type: application/json" -H "Authorization: Bearer YOUR_TOKEN" -d '{"title":"Hello","content":"My first blog"}'
```

## Structure
```
blog-backend/
├── config/db.js
├── controllers/   authController.js, blogController.js
├── middleware/    auth.js
├── models/        User.js, Blog.js
├── routes/        authRoutes.js, blogRoutes.js
├── frontend/      index.html
├── server.js
└── .env
```
