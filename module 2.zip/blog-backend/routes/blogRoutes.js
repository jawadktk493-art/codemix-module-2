const router = require("express").Router();
const { protect } = require("../middleware/auth");
const {
  createBlog,
  getBlogs,
  getBlogById,
  deleteBlog,
} = require("../controllers/blogController");

router.get("/", getBlogs);
router.get("/:id", getBlogById);
router.post("/", protect, createBlog);
router.delete("/:id", protect, deleteBlog);

module.exports = router;
